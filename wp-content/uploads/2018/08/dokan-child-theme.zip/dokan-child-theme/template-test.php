<?php
/**
 * Template Name: test template
 */
get_header();



the_widget('Custom_Dokan_Category_Widget');


get_footer(); 

