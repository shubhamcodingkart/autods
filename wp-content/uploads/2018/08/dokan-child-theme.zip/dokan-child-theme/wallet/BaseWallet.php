<?php
/**
 * BaseWallet class.
 *
 * The BaseWallet Class and  may extend by chlid class to get the comman functionlity .
 *
 * @class    BaseWallet
 * @category Class
 * @author   Codingkart
 */  
class BaseWallet 
{
 
	/**
     * Constructor for the BaseWallet class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {
    
    }

}
new BaseWallet();
?>