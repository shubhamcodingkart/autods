<?php
/**
 * Dokan Report Header Template
 *
 * @since 2.4
 *
 * @package dokan
 */
?>
<header class="dokan-dashboard-header">
    <h1 class="entry-title"><?php _e( 'Reports', 'dokan' ) ?></h1>
</header><!-- .dokan-dashboard-header -->
