<?php
$seo = Dokan_Pro_Store_Seo::init();
?>

<div class="dokan-store-seo-wrapper">
    <?php $seo->frontend_meta_form(); ?>
</div>


