<?php
/**
 * Dokan Account Migration Button Template
 *
 * @since 2.4
 *
 * @package dokan
 */

?>

<p>&nbsp;</p>
<p>
    <a href="<?php echo dokan_get_page_url( 'myaccount', 'woocommerce' ); ?>account-migration/seller/" class="btn btn-primary"><?php _e( 'Become a Vendor', 'dokan' ); ?></a>
</p>
