<?php
/**
 * EditProduct class.
 *
 *
 * @class    EditProduct
 * @category Class
 * @author   Codingkart
 */  
class EditProduct extends BaseAccount
{

     /**
     * Constructor for the EditProduct class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {

    	// Add new Blank product
        add_action( 'wp_ajax_codingkart_add_new_blank_product', array($this,'codingkart_add_new_blank_product') ); 

        // Update meta if product is updated
        add_action( 'dokan_product_updated', array($this,'codingkart_update_blank_product_meta') );    
    }

    /**
     *  Add new Blank product
    */
    public function codingkart_add_new_blank_product(){
  		$args = array(
	    	'author'        =>  get_current_user_id(),
			'post_type'		=>	'product',
			'meta_query'	=>	array(
				array(
					'key' => '_ck_valid_product',
					'value'	=>	'0'
				)
			)
		);
		$my_query = new WP_Query( $args );

		// execute the main query
		$the_main_loop = new WP_Query($args);

		if( $my_query->have_posts() ) {
		  while( $my_query->have_posts() ) {
		    $my_query->the_post();
		    $blank_post_id = get_the_id();
		    // Do your work...
		  } // end while
		} // end if
		wp_reset_postdata();

		// if blank product exist
		if($blank_post_id){
			echo $blank_post_id;
			die;
		}else{ //create a new blank product
			$id = wp_insert_post(array('post_title'=>'Blank', 'post_type'=>'product', 'post_content'=>'', 'post_status'=>'pending', 'post_author'=>get_current_user_id()));
			update_post_meta($id, '_ck_valid_product' , '0');
			print_r($id);
			die;
		}
	}


	/**
     *  Update meta if product is updated
    */
	public function codingkart_update_blank_product_meta($post_id){
		update_post_meta($post_id, '_ck_valid_product' , '1');
	}

	
}
new EditProduct();
?>