<?php
/**
 * EditStore class.
 *
 *
 * @class    EditStore
 * @category Class
 * @author   Codingkart
 */  
class EditStore extends BaseAccount
{

     /**
     * Constructor for the EditStore class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {    
    }

	
}
new EditStore();
?>