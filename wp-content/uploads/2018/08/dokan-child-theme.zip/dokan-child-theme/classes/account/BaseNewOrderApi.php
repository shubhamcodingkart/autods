<?php
/**
 * @class    BaseNewOrderApi
 * @category Class
 * @author   Codingkart
 */  
class BaseNewOrderApi extends WC_REST_Orders_Controller 
{

	/**
     * Constructor for the BaseNewOrderApi class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {

        // Assign vendor to new_order api
    	add_action( 'woocommerce_rest_insert_shop_order_object', array( $this, 'codingkart_assign_vendor_to_new_order_api'));
        add_action( 'woocommerce_api_create_order', array( $this, 'action_function_name_8586'), 10, 3 );

    }
     
	
	
    public function action_function_name_8586( $order_id, $data, $this_ ){
    	$order = wc_get_order( $order_id );
    	$this->codingkart_assign_vendor_to_new_order_api($order);	
    } 
	 
    /**
     *  Assign vendor to new_order api
    */
    public function codingkart_assign_vendor_to_new_order_api( $order ) {
        $array = json_decode(json_encode($order), true);
        print_r($array);
		global $wpdb;
        $order_id = $order->get_id();
        $get_order = wc_get_order( $order_id );
        $its = $get_order->get_items();

        foreach ( $its as $it ) {
            $product_id = $it->get_product_id();
            $post_author_id = get_post_field( 'post_author', $product_id );
            $arg = array(
             'ID' => $order_id,
             'post_author' => $post_author_id,
            );
            wp_update_post( $arg );
            $order_post_author_id = get_post_field( 'post_author', $order_id );

            // update order status to pending
            $the_order = new WC_Order( $order_id );
            $the_order->update_status('wc-pending');

            // insert order data in wp_dokan_orders table
            $table_name = $wpdb->prefix . "dokan_orders";
            $order_total = $order->get_total();
            $wpdb->insert($table_name, array('order_id' => $order_id, 'seller_id' => $post_author_id, 'order_total'=> $order_total, 'order_status' => 'wc-pending') );
        }
		
    }

}
new BaseNewOrderApi();

?>


