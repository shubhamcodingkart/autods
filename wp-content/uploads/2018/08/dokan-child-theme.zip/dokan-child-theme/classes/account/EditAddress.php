<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/wp-content/themes/dokan-child-theme/classes/customers/BaseCustomer.php';
/**
 * EditAddress Class.
 *
 * The EditAddress Account Class and may extend by chlid class to get the comman functionlity .
 *
 * @class    BaseCustomer
 * @category Class
 * @author   Codingkart
 */ 

class EditAddress extends BaseAccount  
{
       
      
	 //global variable and object delceration 
	
	  
	 /**
     * Constructor for the EditAddress class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {      
	  // Adding new extra field on edit account form 
	  add_action( 'woocommerce_edit_account_form',  array( $this,  'codingkart_woocommerce_edit_account_form' ) );
	  // Saving data for new extra field on edit account form 
      add_action( 'woocommerce_save_account_details',  array( $this,  'codingkart_woocommerce_save_account_details' ) ); 
	  
	  
	}
	
	
	/**
     * Adding new extra field on edit account form 
     */
    public function codingkart_woocommerce_edit_account_form() {
          
		  $user_id = get_current_user_id();
		  $user = get_userdata( $user_id );
		  
		  // calling function codingkart_customer_check_user_type with help of BaseCustomer class object
		  $mBaseCustomer=new BaseCustomer();
		  $check_type=$mBaseCustomer->codingkart_customer_check_user_type('subscriber');
		  
		  $autods_token = get_user_meta( $user_id, 'autods_token', true );		   
		  if($check_type)
		  {
		  ?>
		  <fieldset>
			<p class="form-row form-row-thirds">
			  <label for="url">AutoDS Token:</label>
			  <input type="text" value="<?php echo $autods_token; ?>" class="input-text" name="autods_token" />
			</p>
		  </fieldset>
		  <?php
		  }

    }
     
	/**
     * Saving data for new extra field on edit account form 
     */
    public function codingkart_woocommerce_save_account_details() {	 
    	update_user_meta( $user_id, 'autods_token', htmlentities( $_POST[ 'autods_token' ] ) ); 
    }
     
}
new EditAddress();
?>