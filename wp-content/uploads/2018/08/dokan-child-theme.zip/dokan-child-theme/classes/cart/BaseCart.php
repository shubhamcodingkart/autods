<?php
/**
 * Base Cart class.
 *
 * The Base Cart Class and  may extend by chlid class to get the comman functionlity .
 *
 * @class    BaseCart
 * @category Class
 * @author   Codingkart
 */  
class BaseCart 
{
     /**
     * Constructor for the BaseCart class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {
        // get the cart items api reponse ajax function
        add_action( 'wp_ajax_codingkart_get_cart_items_detail_api_fn', array($this,'codingkart_get_cart_items_detail_api_fn') );
        add_action( 'wp_ajax_nopriv_codingkart_get_cart_items_detail_api_fn', array($this,'codingkart_get_cart_items_detail_api_fn' ));
    }

    /**
     * get the cart items api reponse ajax function
     */
	public function codingkart_get_cart_items_detail_api_fn(){
        $all_items = array();
        foreach( WC()->cart->get_cart() as $cart_item ){
            $product_id = $cart_item['product_id'];
            array_push($all_items,$product_id);
        }
        $commaList = implode(',', $all_items);

        $list_items_api_call = new BaseRest;

        $data = $list_items_api_call->codingkart_woocommerce_rest_get_cart_items_api_response(site_url().'/wp-json/wc/v2/products?include=', $commaList);

        wp_send_json($data);
    }
	

}
new BaseCart();
?>