<?php
/**
 * Base Order class.
 *
 * The Order Custom Class.
 *
 * @class    OrderCustom
 * @category Class
 * @author   Codingkart
 */  
class OrderCustom extends BaseOrder 
{
		
}
new OrderCustom();
?>