<?php
/**
 * Base Order class.
 *
 * The Bases Order Class and may extend by chlid class to get the comman functionlity .
 *
 * @class    BaseOrder
 * @category Class
 * @author   Codingkart
 */  
class BaseOrder 
{
	
}
new BaseOrder();
?>