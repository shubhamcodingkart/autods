<?php
/**
 * Base Rest class.
 *
 * The Bases Rest Class and  may extend by chlid class to get the comman functionlity .
 *
 * @class    BaseRest
 * @category Class
 * @author   Codingkart
 */  
class BaseRest 
{
     /**
     * Constructor for the BaseRest class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {
        // change text on withdraw methods
		add_filter( 'woocommerce_rest_check_permissions', array( $this,  'codingkart_woocommerce_rest_check_permissions' ) , 90, 4);  
	}

	
	/**
     * change text on withdraw methods
     */
    public function codingkart_woocommerce_rest_check_permissions($permission, $context, $object_id, $post_type  ){
    	return true;
	}


    /**
     * get the product api reponse
     */
    public function codingkart_woocommerce_rest_get_product_api_response($url, $id){
        $data = file_get_contents($url.$id);
        return $data;
    }

    /**
     * get the create order api reponse
     */
    public function codingkart_woocommerce_rest_create_order_api_response($url, $data){

        $ch = curl_init($url);
        # Form data string
        $postString = http_build_query($data, '', '&');
        # Setting our options
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postString);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        # Get the response
        $response = curl_exec($ch);
        echo $response;
        curl_close($ch);
        die();
    }

    /**
     * get the cart items api reponse
     */
    public function codingkart_woocommerce_rest_get_cart_items_api_response($url, $item_ids){
        $data = file_get_contents($url.$item_ids);
        return $data;
    }

    /**
     * api call on order status changed to shipped
     */
    public function codingkart_woocommerce_rest_order_status_changed_to_shipped($url, $order_id){
        $data = file_get_contents($url.$order_id);
        return $data;
    }

}
new BaseRest();
?>