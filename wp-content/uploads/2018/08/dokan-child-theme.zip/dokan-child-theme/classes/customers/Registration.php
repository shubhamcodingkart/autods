<?php
/**
 * Base Customer class.
 *
 * The Registration Customer Class.
 *
 * @class    Registration
 * @category Class
 * @author   Codingkart
 */  
class Registration extends BaseCustomer  
{
     
	 /**
     * Constructor for the Registration class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {
       
	}

}
new Registration();
?>