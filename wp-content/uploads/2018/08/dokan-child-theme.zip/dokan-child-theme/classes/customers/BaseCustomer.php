<?php
/**
 * Base Customer class.
 *
 * The Bases Customer Class and  may extend by chlid class to get the comman functionlity .
 *
 * @class    BaseCustomer
 * @category Class
 * @author   Codingkart
 */  
class BaseCustomer 
{
 	
 	/**
     * Constructor for the EditProduct class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {

    	//Add BCC to contact vendor form
        add_filter( 'woocommerce_email_headers', array($this,'codingkart_add_bcc_to_contact_vendor_form'), 10, 2);

    }

	/**
	* Saving data for new extra field on edit account form 
	*/
	public function codingkart_customer_check_user_type($type) {	 
		
		$user_id = get_current_user_id();
		$user = get_userdata( $user_id );	

		$user_roles=$user->roles;
		  
		if($user_roles[0]==$type)
		{
		$customer_type=true;
		}
		else
		{
		$customer_type=false;
		}
	  return $customer_type;	 
	}

	/**
	 * Add BCC to contact vendor form
	 */
    public function codingkart_add_bcc_to_contact_vendor_form( $headers, $object ) {

    	if ($object == 'dokan_contact_seller') {
	        $headers .= 'BCC: My name <bcc@autoboostertools.com>' . "\r\n";
	    }

	    return $headers;
	}


}
new BaseCustomer();
?>