<?php
/**
 * Base Checkout class.
 *
 * The Base Checkout Class and  may extend by chlid class to get the comman functionlity .
 *
 * @class    BaseCheckout
 * @category Class
 * @author   Codingkart
 */  
class BaseCheckout 
{
     /**
     * Constructor for the BaseCheckout class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {
    }

}
new BaseCheckout();
?>