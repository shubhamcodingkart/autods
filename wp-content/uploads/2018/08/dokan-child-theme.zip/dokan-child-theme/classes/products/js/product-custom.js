jQuery(document).ready(function() {
    jQuery('.ajax_api_call').click(function() {
      var data_product_id = jQuery(this).attr('data-product_id');

      var id = jQuery(this).attr('id');
      jQuery('#'+id+' i').removeClass('fa-upload');
      jQuery('#'+id+' i').addClass('fa-circle-o-notch');
      jQuery('#'+id+' i').addClass('fa-spin');

      var baseUrl = document.location.origin;
      var ajaxurl = baseUrl+'/wp-admin/admin-ajax.php';
        jQuery.ajax({
          type:    "POST",
          url:     ajaxurl,
          dataType: 'json',
          data: {'action': 'codingkart_woocommerce_get_product_json_data', data_product_id: data_product_id },
          success: function(response) {
            console.log(response);
            // icon change
            jQuery('#'+id+' i').removeClass('fa-circle-o-notch');
            jQuery('#'+id+' i').removeClass('fa-spin');
            jQuery('#'+id+' i').addClass('fa-check');
          }
        });
    });

    jQuery('.product .add_to_cart_button').click(function() {
      var product_id = jQuery(this).attr('data-product_id');
        jQuery('.product #ajax_api_call_'+product_id).css("left", "75px");
    });

    // add title to single product add to cart button
    jQuery(".single_add_to_cart_button").attr("title","Add to cart");


});