<?php
/**
 * Product Class.
 *
 * The Product Custom Class.
 *
 * @class    ProductCustom
 * @category Class
 * @author   Codingkart
 */  
class ProductCustom extends BaseProduct
{
  	 /**
     * Constructor for the Product class
     *
     * Sets up all the appropriate hooks and actions
     * 
     */
    public function __construct() {
        // add custom button on product loop 
		add_action( 'woocommerce_after_shop_loop_item', array( $this, 'codingkart_woocommerce_after_shop_loop_item'), 10);

        add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'codingkart_woocommerce_product_page'), 10);

        // ajax get json of single product
        add_action( 'wp_ajax_codingkart_woocommerce_get_product_json_data', array($this,'codingkart_woocommerce_get_product_json_data') );
        add_action( 'wp_ajax_nopriv_codingkart_woocommerce_get_product_json_data', array($this,'codingkart_woocommerce_get_product_json_data' ));

        // 
	}
	
	/**
     *  add custom button on product loop 
     */
    public function codingkart_woocommerce_after_shop_loop_item() {
	  	global $product;
		$id = $product->get_id();
		echo '<a href="#" onclick="return false;" id="ajax_api_call_'.$id.'" rel="nofollow" data-product_id="'.$id.'" class="ajax_api_call" title="Upload to AutoDS"><i class="fa fa-upload"></i></a>';
	}
	
	
	/**
     *  add custom button on product details 
     */
    public function codingkart_woocommerce_product_page() {
	  	global $product;
		$id = $product->get_id();
		echo '<a href="#" onclick="return false;" id="ajax_api_call_'.$id.'" rel="nofollow" data-product_id="'.$id.'" class="ajax_api_call button" title="Upload to AutoDS">Upload to AutoDS<i class="fa fa-upload"></i></a>';
	}


    /**
     *  get product json data by product id  
     */
    public function codingkart_woocommerce_get_product_json_data() {
        global $woocommerce;
        $id = $_POST['data_product_id'];
        $product_api_call = new BaseRest;

        $data = $product_api_call->codingkart_woocommerce_rest_get_product_api_response(site_url().'/wp-json/wc/v2/products/', $id);

        wp_send_json($data);
    }

    /**
     *  Additional Vendor Information  
     */
    public function codingkart_additional_vendor_information(){ ?>
        <li class="dokan-store-cancellation-rate">
            <i class="fa fa-percent"></i>
            Cancelation rate: 0%
        </li>
        <li class="dokan-store-cancellation-rate">
            <i class="fa fa-percent"></i>
            Returns rate: 2%
        </li>
        <li class="dokan-store-cancellation-rate">
            <i class="fa fa-clock-o"></i>
            Ship on time: 100%
        </li>
        <li class="dokan-store-cancellation-rate">
            <i class="fa fa-clock-o"></i>
            Customer support average response time: Less than a day
        </li>
    <?php }
}
new ProductCustom();

?>