<?php
/**
 * Base Product class.
 *
 * The Bases Product Class and  may extend by chlid class to get the comman functionlity .
 *
 * @class    BaseProduct
 * @category Class
 * @author   Codingkart
 */  
class BaseProduct 
{


}
new BaseProduct();
?>