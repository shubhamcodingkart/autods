jQuery(document).ready(function($){

	// 
   	jQuery('.product-integration-box').click(function() {
		var data_id = jQuery(this).attr('data-id');
		jQuery('#'+data_id).modal('show');

		$('.product_inetgration_form')[0].reset();
		$('.product_inetgration_form .req-field').remove();

	});

   	jQuery('.product_inetgration_form').submit(function(e) {
   		e.preventDefault();

   		var form_id = jQuery(this).attr('id');
   		
   		jQuery('.req-field').remove();

   		var isValid = true;
        $('#'+form_id+' input').each(function() {
            if ($.trim($(this).val()) == '') {
                isValid = false;
                jQuery('<p class="req-field">Required field.</p>').insertAfter(this);
            }
        });
        if (isValid == false){
        	e.preventDefault();
        }
        else{
        	var fd = new FormData(this);
	    	fd.append('action', 'codingkart_product_inetgration_form_ajax'); 
	    	var baseUrl = document.location.origin;
	      	var ajaxurl = baseUrl+'/wp-admin/admin-ajax.php';

		    jQuery.ajax({
		        type:    "POST",
		        url:     ajaxurl,          
		        data: fd,
		        contentType: false,
		        processData: false,
		        beforeSend: function() {
		        },
		        success: function(result) {
		        	jQuery('.product_inetgration_modal').modal('hide');
		        	jQuery('#successful_integration_popup').modal('show');
		        	setTimeout(function(){ window.location.href = baseUrl+"/dashboard/product-integration"; }, 2000);
		        }
		    });
        	//alert('Thank you for submitting');
        }

      	
    });
});