
<?php
/**
 *  Dokan Dashboard Template
 *
 *  Dokan Main Dahsboard template for Fron-end
 *
 *  @since 2.4
 *
 *  @package dokan
 */
?>
<div class="dokan-dashboard-wrap">
    <?php
        /**
         *  dokan_dashboard_content_before hook
         *
         *  @hooked get_dashboard_side_navigation
         *
         *  @since 2.4
         */
        do_action( 'dokan_dashboard_content_before' );
    ?>

    <div class="dokan-dashboard-content">

        <?php
            /**
             *  dokan_dashboard_content_before hook
             *
             *  @hooked show_seller_dashboard_notice
             *
             *  @since 2.4
             */
            do_action( 'dokan_help_content_inside_before' );
        ?>

        <article class="product_inetgration-content-area">
	        <div class="container bg">
				<div class="row">
				    <?php
				    	$args = array('post_type' => 'product_inetgration' );                                              
						$the_query = new WP_Query( $args );

						// The Loop
						if ( $the_query->have_posts() ) {
						    while ( $the_query->have_posts() ) {
						        $the_query->the_post(); 
						        $featured_img_url = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()), 'thumbnail' );
						        $user_id = get_current_user_id();
						        $check_integration_status = get_user_meta( $user_id, '_product_integration_status_'.get_the_ID(), true );
						        ?>

						        <div class="col-xs-12 col-sm-6 col-md-2 rwrapper product-integration-box <?php if($check_integration_status == 1){echo 'product_validation_enabled';}?>" data-id="<?php echo 'product_inetgration_'.get_the_title();?>" id="<?php echo 'box_'.get_the_ID();?>">
							     	<div class="rlisting">
								        <div class="col-md-12 nopad">
								          <img src="<?php echo $featured_img_url ?>" class="img-responsive" style="cursor: pointer;">
								        </div>
								        <div class="col-md-12 nopad">
								          <h5><?php the_title(); ?></h5>
								           <p>Lorem Ipsum is simply dummy text o industry...</p>
								           <!-- <div class="rfooter">
								             <i class="fa fa-phone-square"></i> +3000000
								           </div> -->
								        </div>
							      	</div>
							    </div>

							    <div id="<?php echo 'product_inetgration_'.get_the_title();?>" class="modal fade product_inetgration_modal" role="dialog">
								  <div class="modal-dialog">

								    <!-- Modal content-->
								    <div class="modal-content">
								     	<div class="modal-body">
								     		<h4 class="modal-title">Magento Product Integration</h4>
											<form class="product_inetgration_form" method="post" id="product_inetgration_form_<?php echo get_the_ID(); ?>" data-id="<?php echo get_the_ID(); ?>">
										        <?php 
										        	$popup_function = 'codingkart_product_integration_'.get_the_ID().'_popup_content';
										        	$popup_content = new BaseProductIntegration;
										        	$popup_content->$popup_function();
										        ?>
										        <input type="hidden" name="post_id" id="post_id" value="<?php echo get_the_ID(); ?>">
										        <button type="submit" class="btn btn-primary">Submit</button>
									    	</form>
								      	</div>
								      	<div class="modal-footer">
									        <button type="button" class="btn btn-default product_inetgration_form_submit" data-dismiss="modal">Close</button>
									    </div>
								    </div>

								  </div>
								</div>
						    <?php }
						    /* Restore original Post Data */
						    wp_reset_postdata();
						} else {
						    // no posts found
						}

						$successful_integration_popup = new BaseProductIntegration;
						$successful_integration_popup->codingkart_successful_integration_popup();
					?>

				</div>
			</div>

        </article><!-- .dashboard-content-area -->

         <?php
            /**
             *  dokan_dashboard_content_inside_after hook
             *
             *  @since 2.4
             */
            do_action( 'dokan_dashboard_content_inside_after' );
        ?>


    </div><!-- .dokan-dashboard-content -->

    <?php
        /**
         *  dokan_dashboard_content_after hook
         *
         *  @since 2.4
         */
        do_action( 'dokan_dashboard_content_after' );
    ?>

</div><!-- .dokan-dashboard-wrap -->